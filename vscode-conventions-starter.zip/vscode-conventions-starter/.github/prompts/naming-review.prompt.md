Review this change against `CONVENTIONS.md`.

Check:
1. File and directory naming
2. Identifier naming by language
3. Markdown doc naming
4. Mirrored artifact stem consistency, if configured in `.naming-rules.json`
5. Any undocumented exceptions

Report:
- violations
- exact file/path involved
- proposed rename or rule-compliant replacement
