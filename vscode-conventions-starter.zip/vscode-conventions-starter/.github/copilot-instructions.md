Follow `CONVENTIONS.md`.

Apply naming by identifier category, not file type alone.

Required defaults:
- Python files/functions/variables: `snake_case`
- Python classes: `PascalCase`
- JavaScript functions/variables: `camelCase`
- JavaScript classes: `PascalCase`
- Constants and environment variables: `UPPER_SNAKE_CASE`
- General markdown docs: `kebab-case`
- Mirrored artifacts: preserve canonical filename stem

Do not invent exceptions. If a tool, framework, or external API requires a different convention, keep it at the boundary and document it.
